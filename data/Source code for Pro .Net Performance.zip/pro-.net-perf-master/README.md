# Apress Source Code

This repository accompanies [*Pro .NET Performance*](http://www.apress.com/9781430244585) by Sasha Goldshtein, Dima Zurbalev, SELA Group, and Ido Flatow (Apress, 2012).

![Cover image](9781430244585.jpg)

Download the files as a zip using the green button, or clone the repository to your machine using Git.

## Releases

Release v1.0 corresponds to the code in the published book, without corrections or updates.

## Contributions

See the file Contributing.md for more information on how you can contribute to this repository.
