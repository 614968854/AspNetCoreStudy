﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HelperLibrary
{
    public class UtilityClass
    {
        public static void SayHello()
        {
            Console.WriteLine("Hello, World!");
        }
    }
}
